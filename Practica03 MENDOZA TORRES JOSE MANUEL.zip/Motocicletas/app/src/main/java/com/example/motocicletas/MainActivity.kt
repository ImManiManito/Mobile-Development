package com.example.motocicletas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {


    private val motos = arrayOfNulls<Motocicleta>(10)
    private var indice = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val etMarca = findViewById<EditText>(R.id.etMarca)
        val etModelo = findViewById<EditText>(R.id.etModelo)
        val etAnio = findViewById<EditText>(R.id.etAnio)
        val etPrecio = findViewById<EditText>(R.id.etPrecio)
        val tvMensaje = findViewById<TextView>(R.id.tvMensaje)

        val btnAgregar = findViewById<Button>(R.id.btnAgregar)
        val btnBuscar = findViewById<Button>(R.id.btnBuscar)
        val btnLimpiar = findViewById<Button>(R.id.btnLimpiar)


        btnAgregar.setOnClickListener {
            val marca = etMarca.text.toString()
            val modelo = etModelo.text.toString()
            val anioStr = etAnio.text.toString()
            val precioStr = etPrecio.text.toString()

            if(marca.isNotEmpty() && modelo.isNotEmpty() && anioStr.isNotEmpty() && precioStr.isNotEmpty()){
                val anio = anioStr.toIntOrNull()
                val precio = precioStr.toDoubleOrNull()
                if(anio != null && precio != null){
                    if(indice < motos.size){
                        motos[indice] = Motocicleta(marca, modelo, anio, precio)
                        indice++
                        tvMensaje.text = "Motocicleta agregada exitosamente"
                    } else {
                        tvMensaje.text = "Arreglo lleno, no se pueden agregar más motocicletas"
                    }
                } else {
                    tvMensaje.text = "Año o Precio no son válidos"
                }
            } else {
                tvMensaje.text = "Por favor, complete todos los campos"
            }
        }


        btnBuscar.setOnClickListener {
            val marcaBuscada = etMarca.text.toString()
            if(marcaBuscada.isNotEmpty()){
                var encontrada: Motocicleta? = null
                for (moto in motos) {
                    if (moto != null && moto.marca.equals(marcaBuscada, ignoreCase = true)) {
                        encontrada = moto
                        break
                    }
                }
                if(encontrada != null){
                    etMarca.setText(encontrada.marca)
                    etModelo.setText(encontrada.modelo)
                    etAnio.setText(encontrada.anio.toString())
                    etPrecio.setText(encontrada.precio.toString())
                    tvMensaje.text = "Motocicleta encontrada"
                } else {
                    tvMensaje.text = "No se encontró motocicleta con la marca: $marcaBuscada"
                }
            } else {
                tvMensaje.text = "Ingrese una marca para buscar"
            }
        }


        btnLimpiar.setOnClickListener {
            etMarca.text.clear()
            etModelo.text.clear()
            etAnio.text.clear()
            etPrecio.text.clear()
            tvMensaje.text = ""
        }
    }
}
