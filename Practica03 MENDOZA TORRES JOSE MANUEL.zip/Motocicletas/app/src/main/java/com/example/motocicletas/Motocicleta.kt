package com.example.motocicletas

data class Motocicleta(
    var marca: String,
    var modelo: String,
    var anio: Int,
    var precio: Double
)
