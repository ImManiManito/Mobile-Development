package com.example.concierto

import java.io.Serializable

data class Concierto(
    var codigo: String,
    var nombre: String,
    var artista: String,
    var lugar: String,
    var tipo: String,
    var vip: Boolean
) : Serializable
