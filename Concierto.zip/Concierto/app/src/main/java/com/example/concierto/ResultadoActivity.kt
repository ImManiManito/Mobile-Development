package com.example.conciertosapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.concierto.Concierto
import com.example.concierto.R

class ResultadoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        val concierto = intent.getSerializableExtra("concierto") as? Concierto
        val resultadoText = findViewById<TextView>(R.id.textViewResultado)

        concierto?.let {
            resultadoText.text = """
                Código: ${it.codigo}
                Nombre: ${it.nombre}
                Artista: ${it.artista}
                Lugar: ${it.lugar}
                Tipo: ${it.tipo}
                VIP: ${if (it.vip) "Sí" else "No"}
            """.trimIndent()
        }
    }
}
