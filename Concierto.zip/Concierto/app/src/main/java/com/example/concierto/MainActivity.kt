package com.example.conciertosapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.concierto.Concierto
import com.example.concierto.R
import com.google.android.material.chip.Chip

class MainActivity : AppCompatActivity() {
    private lateinit var codigoEditText: EditText
    private lateinit var nombreEditText: EditText
    private lateinit var artistaEditText: EditText
    private lateinit var lugarSpinner: Spinner
    private lateinit var tipoListView: ListView
    private lateinit var vipSwitch: Switch
    private lateinit var registrarBtn: Button
    private lateinit var buscarBtn: Button
    private lateinit var limpiarBtn: Button
    private lateinit var eliminarBtn: Button

    private var conciertos = arrayOfNulls<Concierto>(5)
    private var index = 0
    private val tipos = arrayOf("Rock", "Pop", "Jazz", "Electrónica", "Indie")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        codigoEditText = findViewById(R.id.editTextCodigo)
        nombreEditText = findViewById(R.id.editTextNombre)
        artistaEditText = findViewById(R.id.editTextArtista)
        lugarSpinner = findViewById(R.id.spinnerLugar)
        tipoListView = findViewById(R.id.listViewTipo)
        vipSwitch = findViewById(R.id.switchVip)
        registrarBtn = findViewById(R.id.buttonRegistrar)
        buscarBtn = findViewById(R.id.buttonBuscar)
        limpiarBtn = findViewById(R.id.buttonLimpiar)
        eliminarBtn = findViewById(R.id.buttonEliminar)

        lugarSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, resources.getStringArray(R.array.lugares))

        tipoListView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, tipos)
        tipoListView.choiceMode = ListView.CHOICE_MODE_SINGLE

        registrarBtn.setOnClickListener {
            if (index >= conciertos.size) {
                Toast.makeText(this, getString(R.string.sin_espacio), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val codigo = codigoEditText.text.toString()
            val nombre = nombreEditText.text.toString()
            val artista = artistaEditText.text.toString()
            val lugar = lugarSpinner.selectedItem.toString()
            val tipo = tipos.getOrNull(tipoListView.checkedItemPosition) ?: ""
            val vip = vipSwitch.isChecked

            if (codigo.isEmpty() || nombre.isEmpty() || artista.isEmpty() || tipo.isEmpty()) {
                Toast.makeText(this, getString(R.string.campos_obligatorios), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            conciertos[index++] = Concierto(codigo, nombre, artista, lugar, tipo, vip)
            Toast.makeText(this, getString(R.string.registro_exitoso), Toast.LENGTH_SHORT).show()
            limpiarCampos()
        }

        buscarBtn.setOnClickListener {
            val codigo = codigoEditText.text.toString()
            val concierto = conciertos.find { it?.codigo == codigo }

            if (concierto != null) {
                val intent = Intent(this, ResultadoActivity::class.java)
                intent.putExtra("concierto", concierto)
                startActivity(intent)
            } else {
                Toast.makeText(this, getString(R.string.no_encontrado), Toast.LENGTH_SHORT).show()
            }
        }

        limpiarBtn.setOnClickListener {
            limpiarCampos()
        }

        eliminarBtn.setOnClickListener {
            val codigo = codigoEditText.text.toString()
            for (i in conciertos.indices) {
                if (conciertos[i]?.codigo == codigo) {
                    conciertos[i] = null
                    Toast.makeText(this, getString(R.string.eliminado), Toast.LENGTH_SHORT).show()
                    limpiarCampos()
                    return@setOnClickListener
                }
            }
            Toast.makeText(this, getString(R.string.no_encontrado), Toast.LENGTH_SHORT).show()
        }
    }

    private fun limpiarCampos() {
        codigoEditText.text.clear()
        nombreEditText.text.clear()
        artistaEditText.text.clear()
        tipoListView.clearChoices()
        tipoListView.requestLayout()
        lugarSpinner.setSelection(0)
        vipSwitch.isChecked = false
    }
}
