package com.example.ropadeportiva


class RopaDeportiva(
    var codigo: String,
    var marca: String,
    var modelo: String,
    var talla: String,
    var colores: ArrayList<String>,
    var costo: Double
)
