package com.example.ropadeportiva

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.ToggleButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton


class MainActivity : AppCompatActivity() {

    private val registros = arrayOfNulls<RopaDeportiva>(15)
    private var indiceRegistro = 0 // Indica la próxima posición libre del arreglo
    private var indiceEncontrado = -1 // Guarda la posición del registro encontrado

    // Declaración de los componentes de la interfaz
    private lateinit var etCodigo: EditText
    private lateinit var etMarca: EditText
    private lateinit var etModelo: EditText
    private lateinit var etCosto: EditText
    private lateinit var toggleTalla: ToggleButton
    private lateinit var cbNegro: CheckBox
    private lateinit var cbBlanco: CheckBox
    private lateinit var cbAzul: CheckBox
    private lateinit var cbRojo: CheckBox
    private lateinit var cbNaranja: CheckBox
    private lateinit var tvMensaje: TextView
    private lateinit var btnRegistrar: Button
    private lateinit var btnBuscar: Button
    private lateinit var btnEliminar: Button
    private lateinit var btnLimpiar: Button
    private lateinit var fabRegistrar: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Vinculación de Componentes
        etCodigo = findViewById(R.id.etCodigo)
        etMarca = findViewById(R.id.etMarca)
        etModelo = findViewById(R.id.etModelo)
        etCosto = findViewById(R.id.etCosto)
        toggleTalla = findViewById(R.id.toggleTalla)
        cbNegro = findViewById(R.id.cbNegro)
        cbBlanco = findViewById(R.id.cbBlanco)
        cbAzul = findViewById(R.id.cbAzul)
        cbRojo = findViewById(R.id.cbRojo)
        cbNaranja = findViewById(R.id.cbNaranja)
        tvMensaje = findViewById(R.id.tvMensaje)
        btnRegistrar = findViewById(R.id.btnRegistrar)
        btnBuscar = findViewById(R.id.btnBuscar)
        btnEliminar = findViewById(R.id.btnEliminar)
        btnLimpiar = findViewById(R.id.btnLimpiar)
        fabRegistrar = findViewById(R.id.fabRegistrar)

        // Asignación de los eventos para cada botón
        btnRegistrar.setOnClickListener { registrar() }
        fabRegistrar.setOnClickListener { registrar() } // El FAB realiza la misma acción que Registrar
        btnBuscar.setOnClickListener { buscar() }
        btnEliminar.setOnClickListener { eliminar() }
        btnLimpiar.setOnClickListener { limpiarCampos() }
    }

    private fun registrar() {
        if (indiceRegistro >= registros.size) {
            tvMensaje.text = getString(R.string.msg_no_espacio)
            return
        }
        val codigo = etCodigo.text.toString().trim()
        val marca = etMarca.text.toString().trim()
        val modelo = etModelo.text.toString().trim()
        val costo = etCosto.text.toString().trim().toDoubleOrNull()
        if (costo == null) {
            tvMensaje.text = "Costo inválido"
            return
        }

        // Obtener la talla a partir del ToggleButton (si está activado, se interpreta como "Mediana", sino "Chica")
        val talla = if (toggleTalla.isChecked) getString(R.string.talla_mediana) else getString(R.string.talla_chica)

        // Recoger los colores seleccionados en una lista
        val colores = arrayListOf<String>()
        if (cbNegro.isChecked) colores.add(getString(R.string.color_negro))
        if (cbBlanco.isChecked) colores.add(getString(R.string.color_blanco))
        if (cbAzul.isChecked) colores.add(getString(R.string.color_azul))
        if (cbRojo.isChecked) colores.add(getString(R.string.color_rojo))
        if (cbNaranja.isChecked) colores.add(getString(R.string.color_naranja))

        // Creación del objeto RopaDeportiva
        val ropa = RopaDeportiva(codigo, marca, modelo, talla, colores, costo)
        registros[indiceRegistro] = ropa
        indiceRegistro++

        tvMensaje.text = getString(R.string.msg_registro_exitoso)
        limpiarCampos()
    }

    private fun buscar() {
        val codigoBuscar = etCodigo.text.toString().trim()
        var encontrado = false
        for (i in 0 until indiceRegistro) {
            val registro = registros[i]
            if (registro != null && registro.codigo == codigoBuscar) {
                // Se cargan los datos del registro en la interfaz
                etMarca.setText(registro.marca)
                etModelo.setText(registro.modelo)
                etCosto.setText(registro.costo.toString())
                // Configuración del ToggleButton según la talla
                toggleTalla.isChecked = registro.talla == getString(R.string.talla_mediana)
                // Reinicializar los CheckBox y luego marcar los que correspondan
                cbNegro.isChecked = false
                cbBlanco.isChecked = false
                cbAzul.isChecked = false
                cbRojo.isChecked = false
                cbNaranja.isChecked = false
                for (color in registro.colores) {
                    when (color) {
                        getString(R.string.color_negro) -> cbNegro.isChecked = true
                        getString(R.string.color_blanco) -> cbBlanco.isChecked = true
                        getString(R.string.color_azul) -> cbAzul.isChecked = true
                        getString(R.string.color_rojo) -> cbRojo.isChecked = true
                        getString(R.string.color_naranja) -> cbNaranja.isChecked = true
                    }
                }
                tvMensaje.text = ""
                indiceEncontrado = i
                encontrado = true
                break
            }
        }
        if (!encontrado) {
            tvMensaje.text = getString(R.string.msg_busqueda_no_encontrada)
            indiceEncontrado = -1
        }
    }

    private fun eliminar() {
        if (indiceEncontrado == -1) {
            tvMensaje.text = getString(R.string.msg_error_buscar_primero)
            return
        }
        // Se recorren los elementos para moverlos a la izquierda, eliminando el registro
        for (i in indiceEncontrado until indiceRegistro - 1) {
            registros[i] = registros[i + 1]
        }
        registros[indiceRegistro - 1] = null
        indiceRegistro--
        tvMensaje.text = getString(R.string.msg_eliminado)
        limpiarCampos()
        indiceEncontrado = -1
    }

    private fun limpiarCampos() {
        etCodigo.text.clear()
        etMarca.text.clear()
        etModelo.text.clear()
        etCosto.text.clear()
        toggleTalla.isChecked = false
        cbNegro.isChecked = false
        cbBlanco.isChecked = false
        cbAzul.isChecked = false
        cbRojo.isChecked = false
        cbNaranja.isChecked = false
        tvMensaje.text = ""
    }
}
