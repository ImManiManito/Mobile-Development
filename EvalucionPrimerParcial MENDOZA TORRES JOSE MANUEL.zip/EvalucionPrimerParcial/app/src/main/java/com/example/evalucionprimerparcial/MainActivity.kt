package com.example.evalucionprimerparcial

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup


open class Auto(val marca: String, val modelo: String)

class AutoEnRenta(marca: String, modelo: String, val precioPorDia: Double, val disponible: Boolean) :
    Auto(marca, modelo)

class MainActivity : AppCompatActivity() {


    private val autosEnRenta = arrayOfNulls<AutoEnRenta>(5)
    private var posicion = 0

    private lateinit var etMarca: EditText
    private lateinit var etModelo: EditText
    private lateinit var etPrecio: EditText
    private lateinit var chipGroupDisponibilidad: ChipGroup
    private lateinit var btnRegistrar: Button
    private lateinit var btnBuscar: Button
    private lateinit var btnLimpiar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar componentes
        etMarca = findViewById(R.id.etMarca)
        etModelo = findViewById(R.id.etModelo)
        etPrecio = findViewById(R.id.etPrecio)
        chipGroupDisponibilidad = findViewById(R.id.chipGroupDisponibilidad)
        btnRegistrar = findViewById(R.id.btnRegistrar)
        btnBuscar = findViewById(R.id.btnBuscar)
        btnLimpiar = findViewById(R.id.btnLimpiar)

        btnRegistrar.setOnClickListener { registrarAuto() }
        btnBuscar.setOnClickListener { buscarAuto() }
        btnLimpiar.setOnClickListener { limpiarCampos() }
    }

    private fun registrarAuto() {
        val marca = etMarca.text.toString().trim()
        val modelo = etModelo.text.toString().trim()
        val precioStr = etPrecio.text.toString().trim()

        // Validaciones
        if (marca.isEmpty() || modelo.isEmpty() || precioStr.isEmpty() || chipGroupDisponibilidad.checkedChipId == -1) {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        if (posicion >= autosEnRenta.size) {
            Toast.makeText(this, "Límite de registros alcanzado", Toast.LENGTH_SHORT).show()
            return
        }

        val precio = precioStr.toDouble()
        val chipSeleccionado = findViewById<Chip>(chipGroupDisponibilidad.checkedChipId)
        val disponible = chipSeleccionado.text.toString() == "Disponible"

        // Guardar en el arreglo
        autosEnRenta[posicion] = AutoEnRenta(marca, modelo, precio, disponible)
        posicion++
        Toast.makeText(this, "Auto registrado exitosamente", Toast.LENGTH_SHORT).show()

        limpiarCampos()
    }

    private fun buscarAuto() {
        val marcaBuscada = etMarca.text.toString().trim()

        if (marcaBuscada.isEmpty()) {
            Toast.makeText(this, "Ingrese la marca a buscar", Toast.LENGTH_SHORT).show()
            return
        }

        for (auto in autosEnRenta) {
            if (auto != null && auto.marca.equals(marcaBuscada, ignoreCase = true)) {
                etModelo.setText(auto.modelo)
                etPrecio.setText(auto.precioPorDia.toString())

                // Seleccionar el Chip correspondiente
                val chipId = if (auto.disponible) R.id.chipDisponible else R.id.chipNoDisponible
                chipGroupDisponibilidad.check(chipId)

                Toast.makeText(this, "Auto encontrado", Toast.LENGTH_SHORT).show()
                return
            }
        }

        Toast.makeText(this, "Auto no encontrado", Toast.LENGTH_SHORT).show()
    }

    private fun limpiarCampos() {
        etMarca.text.clear()
        etModelo.text.clear()
        etPrecio.text.clear()
        chipGroupDisponibilidad.clearCheck()
        etMarca.requestFocus()
    }
}