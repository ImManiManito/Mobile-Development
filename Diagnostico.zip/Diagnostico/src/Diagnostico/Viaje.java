package Diagnostico;
/**
 *
 * @author Jose Manuel Mendoza Torres 22310349
 */
public class Viaje {
    // Variables
    private int id;
    private String destino;
    private int numAsientos;
    private double precio;
    private String fecha;

    // Constructor 
    public Viaje(int id, String destino, int numAsientos, double precio, String fecha) {
        this.id = id;
        this.destino = destino;
        this.numAsientos = numAsientos;
        this.precio = precio;
        this.fecha = fecha;
    }

    // Getters y Setters para cada Variable
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getDestino() {
        return destino;
    }
    public void setDestino(String destino) {
        this.destino = destino;
    }

    public int getNumAsientos() {
        return numAsientos;
    }
    public void setNumAsientos(int numAsientos) {
        this.numAsientos = numAsientos;
    }

    public double getPrecio() {
        return precio;
    }
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    // Sobrescritura del método toString para facilitar la visualización
    @Override
    public String toString() {
        return "Viaje [id=" + id + ", destino=" + destino + ", numAsientos=" + numAsientos
               + ", precio=" + precio + ", fecha=" + fecha + "]";
    }
}

