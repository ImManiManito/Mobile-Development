package Diagnostico;
/**
 *
 * @author Jose Manuel Mendoza Torres 22310349
 */
public class GestorViajes {
    private Viaje[] viajes;
    private int count;  // lleva la cuenta de elementos en el arreglo

    // Constructor: se define un arreglo de tamaño fijo (por ejemplo, 100)
    public GestorViajes() {
        viajes = new Viaje[100];
        count = 0;
    }

    // Método para agregar un objeto Viaje al arreglo
    public void agregarViaje(Viaje v) {
        if (count < viajes.length) {
            viajes[count] = v;
            count++;
        } else {
            System.out.println("No se pueden agregar más viajes.");
        }
    }

    // Método para recorrer el arreglo y retornar la información de todos los viajes
    public String recorrerViajes() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(viajes[i].toString()).append("\n");
        }
        return sb.toString();
    }

    // Método para eliminar un viaje buscándolo por su id
    public boolean eliminarViaje(int id) {
        for (int i = 0; i < count; i++) {
            if (viajes[i].getId() == id) {
                // Desplazar los elementos para "eliminar" el viaje encontrado
                for (int j = i; j < count - 1; j++) {
                    viajes[j] = viajes[j + 1];
                }
                viajes[count - 1] = null;
                count--;
                return true;
            }
        }
        return false;  // No se encontró el viaje
    }

    // Método para buscar un viaje por id
    public Viaje buscarViaje(int id) {
        for (int i = 0; i < count; i++) {
            if (viajes[i].getId() == id) {
                return viajes[i];
            }
        }
        return null;
    }
}

